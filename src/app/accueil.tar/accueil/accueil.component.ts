import { Component, OnInit } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { OrangeMoneyService } from '../webServiceClients/Orangemoney/orangemoney.service' ;

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.css']
})
export class AccueilComponent implements OnInit {
  process=[];
	
  registredAPIs : string [] = ['POSTECASH', 'ORANGE MONEY', 'TIGO CASH', 'TNT BY EXCAF'] ;
  //registredAPIs : string [] = ['POSTECASH', 'TNT BY EXCAF'] ;
  authorisedToUseCRM = false ;
  load="loader";
  constructor(private router: Router,private omService : OrangeMoneyService,) {}

  ngOnInit() {
    if (!sessionStorage.getItem('currentUser')) 
       this.router.navigate(['']);  
    this.processus(); 
  }
  processus(){
    setInterval(()=>{
    if(sessionStorage.getItem('curentProcess')){
      let sesion=JSON.parse(sessionStorage.getItem('curentProcess'));
     // var newprocess={'operation':sesion.operation,'montant':sesion.montant,'num':sesion.num};
      var id=this.process.length;
      sesion.id=id;
      this.process.push(sesion);
      console.log(sesion);
      sessionStorage.removeItem('curentProcess');
      var operateur=sesion.operateur;
      switch(operateur){
        case 1:{}
        
        case 2:{
               var operation=sesion.operation;
              switch(operation){
                case 1:{
                       this.deposer(sesion);
                       break;
                       }
                case 2:{
                       this.retirer(sesion);
                       break;
                }
                case 3:{
                       this.retraitAvecCode(sesion);
                       break;
                }
                case 4:{
                       this.retraitCpteRecep(sesion);
                       break;
                }
                case 5:{
                       this.acheterCredit(sesion);
                       break;
                }
                default :break;
              }
              break;
        }
        default:break;
      }
      
    }
    else{
     console.log('not nice');
    }
  },3000);
  }
  deposer(objet:any){
    let requete = "1/"+objet.montant+"/"+objet.num ;
   
   
    this.omService.requerirControllerOM(requete).then( resp => {
      if (resp.status==200){
        console.log("We just say : "+resp._body) ;
        if (resp._body.trim().toString()=='1'){
         console.log('depot reussi');
         objet.etat=true;
         objet.load='terminated';
         objet.color='green';
        
         
        }
        else{
            
        }
      }
      else
        console.log("error") ; 
    });
    
  }
  retirer(objet:any){
    let requete = "2/"+objet.numclient+"/"+objet.montant ;
    /*setTimeout(()=>{ objet.etat=true;
    objet.load='terminated';
    objet.etat=true;
    objet.color='green';},5000);*/
    this.omService.requerirControllerOM(requete).then( resp => {
      if (resp.status==200){
        //if (resp._body.trim().toString()=='1'){
           console.log('operation reussi');
           
           setTimeout(()=>{
              setInterval(()=>{
              this.omService.verifretaitOM(resp._body.trim().toString()).then(rep =>{
                var donnee=rep;
               // var donnee='0';
                
                  if(donnee=='0'){
                     objet.etat=true;
                     objet.load='terminated';
                     objet.color='green';
                  }
                 });
              },10000);
           },30000);
        //}
      }
      else{
        console.log("error") ; 
        
        }
    });
    
  }
   retraitAvecCode(objet:any){
   /*setTimeout(()=>{ objet.etat=true;
    objet.load='terminated';
    objet.etat=true;
    objet.color='green';},5000);*/
    let requete = "3/"+objet.coderetrait+"/"+objet.prenom+"/"+objet.nomclient+"/"+objet.date+"/"+objet.cni+"/"+objet.numclient;
    this.omService.requerirControllerOM(requete).then( resp => {
      if (resp.status==200){
        console.log(resp._body);
        if (resp._body.trim().toString()=='1'){
          console.log('operation reussi');
          objet.etat=true;
          objet.load='terminated';
          objet.color='green';
          this.process[objet.id]=objet;
        }
      }
      else
        console.log("error") ; 
    });
    
  }
  retraitCpteRecep(objet:any){
    /*setTimeout(()=>{ objet.etat=true;
    objet.load='terminated';
    objet.etat=true;
    objet.color='green';},5000);*/
    let requete = "4/"+objet.numclient+"/"+objet.montant;
    
    this.omService.requerirControllerOM(requete).then( resp => {
      if (resp.status==200){
        if (resp._body.trim().toString()=='1'){
          objet.etat=true;
          objet.load='terminated';
          objet.color='green';
          this.process[objet.id]=objet;
        }
      }
      else
        console.log("error") ; 
    });
  }
  acheterCredit(objet:any){
    let requete = "5/"+objet.numclient+"/"+objet.montant;
 
    this.omService.requerirControllerOM(requete).then( resp => {
      if (resp.status==200){
        if (resp._body=='1'){
          objet.etat=true;
          objet.load='terminated';
          objet.color='green';
          this.process[objet.id]=objet;
        }
      }
      else
        console.log("error") ; 
    }) ;
  }

}
